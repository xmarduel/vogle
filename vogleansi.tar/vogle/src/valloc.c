#include "vogle.h"
#include <stdlib.h>

/*
 * vallocate
 *
 *	Allocate some memory, barfing if malloc returns NULL.
 */
char *
vallocate(unsigned size)
{
	char	*p, buf[60];

	if ((p = (char *)calloc(size, 1)) == (char *)0) {
		sprintf(buf,"vallocate: request for %d bytes returned NULL", size);
		verror(buf);
	}

	return (p);
}
