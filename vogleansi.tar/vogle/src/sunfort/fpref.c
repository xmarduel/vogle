#include "vogle.h"

/*
 * prefposition_
 */
void
prefposition_(int *x, int *y)
{
	prefposition(*x, *y);
}

/*
 * prefsize_
 */
void
prefsize_(int *x, int *y)
{
	prefsize(*x, *y);
}
