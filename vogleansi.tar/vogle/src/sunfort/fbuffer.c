#include "vogle.h"

/*
 * backbuffer_
 */
int
backbuffer_(void)
{
	return(backbuffer());
}

/*
 * frontbuffer_
 */
void
frontbuffer_(void)
{
	frontbuffer();
}

/*
 * swapbuffers_
 */
int
swapbuffers_(void)
{
	return(swapbuffers());
}
