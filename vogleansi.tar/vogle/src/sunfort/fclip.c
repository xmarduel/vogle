#include "vogle.h"

/*
 * clipping
 *
 *	turn clipping on/off
 */
void
clipping_(int *onoff)
{
	vdevice.clipoff = !*onoff;
}
