#include "vogle.h"

/*
 * pushmatrix_
 */
void
pushmatrix_(void)
{
	pushmatrix();
}

/*
 * popmatrix_
 */
void
popmatrix_(void)
{
	popmatrix();
}

/*
 * getmatrix_
 */
void
getmatrix_(Matrix mat)
{
	getmatrix(mat);
}

/*
 * loadmatrix_
 */
void
loadmatrix_(Matrix mat)
{
	loadmatrix(mat);
}

/*
 * multmatrix_
 */
void
multmatrix_(Matrix mat)
{
	multmatrix(mat);
}
