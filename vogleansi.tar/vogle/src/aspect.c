#include "vogle.h"

#define	MIN(x, y)	((x) < (y) ? (x) : (y))

/*
 * getaspect
 *
 *	Gets the aspect ratio of the display/window.
 *	IE. y / x
 */
float
getaspect(void)
{
	return((float)vdevice.sizeSy / (float)vdevice.sizeSx);
}

/*
 * getdisplaysize
 *
 *	Returns the raw size of the display window in pixel units
 *	as floating point values.
 */
void
getdisplaysize(float *x, float *y)
{
	*x = (float)vdevice.sizeSx;
	*y = (float)vdevice.sizeSy;
}

/*
 * getfactors
 *
 *	returns two x and y scaling factors for use with the
 *	viewport call so as the viewport can be set to the
 *	whole display/window.
 */
void
getfactors(float *x, float *y)
{
	*x = (float)vdevice.sizeSx / (float)vdevice.sizeX;
	*y = (float)vdevice.sizeSy / (float)vdevice.sizeY;
}

/*
 * expandviewport
 *
 *	Vogle will normally use the largest square it can fit onto the 
 * actual display device. This call says to use the whole device... however
 * you must then take into account any distortion that will occur due to 
 * the non square mapping.
 */
void
expandviewport(void)
{
	vdevice.attr->a.exvp = 1;
	vdevice.sizeX = vdevice.sizeSx;
	vdevice.sizeY = vdevice.sizeSy;

	CalcW2Vcoeffs();
}

/*
 * unexpandviewport
 * 	- opposite of the above...
 */
void
unexpandviewport(void)
{
	vdevice.attr->a.exvp = 0;
	vdevice.sizeY = vdevice.sizeX = MIN(vdevice.sizeSx, vdevice.sizeSy);

	CalcW2Vcoeffs();
}
