#ifndef ___VOGLE_INC

#define ___VOGLE_INC 1

#include <stdio.h>

/*
 * default location for font library
 */
#ifdef PC	/* Stupid pox head crap */
#define	FONTLIB	"c:\\lib\\hershey\\"
 #ifndef __OS2__	/* BCOS2 defines malloc as a void pointer */
#ifndef TC
 char	*malloc();
#endif
 #endif
#endif

extern	char	*vallocate(unsigned size);

#ifndef FONTLIB
#define FONTLIB	"/usr/local/lib/hershey/"
#endif

/*
 * standard colour indices
 */
#define	BLACK		0
#define	RED		1
#define	GREEN		2
#define	YELLOW		3
#define	BLUE		4
#define	MAGENTA		5
#define	CYAN		6
#define	WHITE		7

/*
 * Hershey text justification
 */
#define V_XCENTERED	1
#define V_YCENTERED	2
#define V_LEFT		4	/* The default */
#define V_RIGHT		8
#define V_TOP		16
#define V_BOTTOM	32	/* The default */
/*
 * Text weights 
 */
#define NORMAL		0	/* The default */
#define BOLD		1

/*
 * Line thickness
 */
#define THIN		0
#define THICK		1

/*
 * when (if ever) we need the precision
 */
#ifdef DOUBLE
#define	float	double
#endif

/*
 * How to convert degrees to radians
 */
#ifndef PI
#define	PI	3.14159265358979323844
#endif
#define D2R	(PI / 180.0)

/*
 * miscellaneous typedefs and type defines
 */
typedef float	Vector[4];
typedef float	Matrix[4][4];
typedef float	Tensor[4][4][4];

/*
 * when register variables get us into trouble
 */
#ifdef NOREGISTER
#define	register
#endif

/*
 * max number of vertices in a ploygon
 */
#define	MAXVERTS	128

/*
 * max number of characters in a font name
 */
#define	FONTNAMELEN	256

/*
 * object definitions
 */
#define MAXENTS		101		/* size of object table */
#define	MAXTOKS		100		/* num. of tokens alloced at once in
					   an object  */

/*
 * functions which can appear in objects
 */
#define	ARC		1
#define	BOXTEXT		2
#define	CALLOBJ		3
#define	CENTERTEXT	4
#define	CIRCLE		5
#define	CLEAR		6
#define	COLOR		7
#define	DRAW		8
#define	DRAWCHAR	9
#define	DRAWSTR		10
#define	FIXEDWIDTH	11
#define	VFONT		12
#define	HATCHANG	13
#define	HATCHPITCH	14
#define	LOADMATRIX	15
#define	MAPCOLOR	16
#define	MOVE		17
#define	MULTMATRIX	18
#define	POLY		19
#define	POLYFILL	20
#define	POLYHATCH	21
#define	POPATTRIBUTES	22
#define	POPMATRIX	23
#define	POPVIEWPORT	24
#define	PUSHATTRIBUTES	25
#define	PUSHMATRIX	26
#define	PUSHVIEWPORT	27
#define	RCURVE		28
#define	RPATCH		29
#define	SECTOR		30
#define	TEXTANG		31
#define	TEXTSIZE	32
#define	VIEWPORT	33
#define	BACKBUFFER	34
#define	FRONTBUFFER	35
#define	SWAPBUFFER	36
#define	BACKFACING	37
#define	TRANSLATE	38
#define	ROTATE		39
#define	SCALE		40
#define	VFLUSH		41

/*
 * data types for object tokens
 */
typedef union tk {
	int		i;
	float		f;
} Token;

typedef struct tls {
	int		count;
	Token		*toks;
	struct tls	*next;
} TokList;

/*
 * attributes
 */
typedef struct {
	char		*style,
			*dashp,
			fill,
			hatch,
			backface,
			justify,
			bold,
			backbuf,
			exvp,
			softtext,
			fixedwidth;
	int		color;
	float		fontheight;
	float		fontwidth;
	float		skew;
	float		hatchcos,
			hatchsin,
			hatchpitch;
	float		textcos,
			textsin;
	float		dash,
			adist;
	char		font[FONTNAMELEN];
} Attribute;

/*
 * viewport
 */
typedef struct vp {
	float	left;
	float	right;
	float	bottom;
	float	top;
} Viewport; 

/*
 * stacks
 */
typedef	struct	ms {	/* Matrix stack entries	*/
	Matrix		m;
	struct	ms	*back;
} Mstack;

typedef	struct	as {	/* Attribute stack entries */
	Attribute	a;
	struct	as	*back;
} Astack;

typedef	struct	vs {	/* Viewport stack entries */
	Viewport	v;
	struct	vs	*back;
} Vstack;

/*
 * vogle device structures
 */
typedef struct dev {
	char	*devname;		/* name of device */
	char	*large,			/* name of large font */
		*small;			/* name of small font */
	int	(*Vbackb)(void),		/* Set drawing in back buffer */
		(*Vchar)(char),		/* Draw a hardware character */
		(*Vcheckkey)(void),		/* Ckeck if a key was hit */
		(*Vclear)(void),		/* Clear the screen to current color */
		(*Vcolor)(int),		/* Set current color */
		(*Vdraw)(int, int),		/* Draw a line */
		(*Vexit)(void),		/* Exit graphics */
		(*Vfill)(int, int [], int []),		/* Fill a polygon */
		(*Vfont)(char *),		/* Set hardware font */
		(*Vfrontb)(void),		/* Set drawing in front buffer */
		(*Vgetkey)(void),		/* Wait for and get the next key hit */
		(*Vinit)(void),		/* Initialise the device */
		(*Vlocator)(int *, int *),		/* Get mouse/cross hair position */
		(*Vmapcolor)(int, int, int, int),		/* Set color indicies */
		(*Vsetlw)(int),		/* Set line thickness */
		(*Vstring)(char *),		/* Draw a hardware string */
		(*Vswapb)(void),		/* Swap front and back buffers */
		(*Vsync)(void);		/* Syncronise the display */
} DevEntry;

typedef struct vdev {
	char		initialised,
			clipoff,
			inobject,
			inpolygon,
			upset,			/* is up vector set */
			cpVvalid,		/* is the current device position valid */
			sync,			/* Do we syncronise the display */
			inbackbuffer,		/* are we in the backbuffer */
			clipplanes;		/* active clipping planes */
	void		(*pmove)(float, float, float),		/* Polygon moves */
			(*pdraw)(float, float, float);		/* Polygon draws */
	TokList		*tokens;		/* ptr to list of tokens for current object */
	Mstack		*transmat;		/* top of transformation stack */
	Astack		*attr;			/* top of attribute stack */
	Vstack		*viewport;		/* top of viewport stack */
	float		hheight, hwidth;	/* hardware character height, width */
	Vector		cpW,			/* current postion in world coords */
			cpWtrans,		/* current world coords transformed */
			upvector;		/* world up */
	int		depth,			/* # bit planes on screen */
			maxVx, minVx,
			maxVy, minVy,
			sizeX, sizeY, 		/* size of square on screen */
			sizeSx, sizeSy,		/* side in x, side in y (# pixels) */
			cpVx, cpVy;
	DevEntry	dev;
} Device;

extern Device	vdevice;		/* device structure */

#define	V_X	0			/* x axis in cpW */
#define	V_Y	1			/* y axis in cpW */
#define	V_Z	2			/* z axis in cpW */
#define	V_W	3			/* w axis in cpW */

/*
 * function definitions
 */

/*
 * allocate memory
 */
extern	char	*vallocate(unsigned size);

/*
 * arc routines
 */
extern void	arc(float x,float y,float radius, float startang, float endang);
extern void	circle(float x, float y, float radius);
extern void	arcprecision(int noseg);
extern void	circleprecision(int noseg);
extern void	sector(float x, float y,float radius,float startang,float endang);

/*
 * attr routines
 */
extern void	popattributes(void);
extern void	pushattributes(void);

/*
 * curve routines
 */
extern void	curve(float geom[4][3]);
extern void	rcurve(Matrix geom);
extern void	curven(int n, float geom[][3]);
extern void	drcurve(int n, Matrix r);
extern void	curvebasis(Matrix basis);
extern void	curveprecision(int nsegments);

/*
 * draw routines
 */
extern void	draw(float x, float y, float z);
extern void	draw2(float x, float y);
extern void	rdraw(float dx, float dy, float dz);
extern void	rdraw2(float dx, float dy);
extern void	sdraw2(float xs, float ys);
extern void	rsdraw2(float dxs, float dys);
extern void	setdash(float d);
extern void	dashline(Vector p0, Vector p1);
extern void	linestyle(char *l);

/*
 * device routines
 */
extern void	clear(void);
extern void	color(int i);
extern int	getdepth(void);
extern int	getkey(void);
extern int	checkkey(void);
extern int	getplanes();
extern int	locator(float *wx, float *wy);
extern int	slocator(float *wx, float *wy);
extern void	mapcolor(int i, short r, short g, short b);

extern void	vinit(char *device);
extern void	vexit(void);
extern void	verror(char *str);
extern void	voutput(char *path);
extern void	vnewdev(char *device);
extern void	pushdev(char *device);
extern void	popdev(void);
extern char	*vgetdev(char *buf);

extern void	linewidth(int w);

/*
 * mapping routines
 */
extern int	WtoVx(float p[]);
extern int	WtoVy(float p[]);
extern void	VtoWxy(float xs, float ys, float *xw, float *yw);
extern void	CalcW2Vcoeffs(void);

/*
 * general matrix and vector routines
 */
extern void	mult4x4(Matrix a, Matrix b,Matrix c);
extern void	copymatrix(Matrix a, Matrix b);
extern void	identmatrix(Matrix a);
extern void	copytranspose(Matrix a, Matrix b);

extern void	multvector(Vector v, Vector a, Matrix b);
extern void	copyvector(Vector a, Vector b);
extern void	premultvector(Vector v, Vector a, Matrix b);

/*
 * matrix stack routines
 */
extern void	getmatrix(Matrix m);
extern void	popmatrix(void);
extern void	loadmatrix(Matrix mat);
extern void	pushmatrix(void);
extern void	multmatrix(Matrix mat);
extern Matrix	*getmstackaddress();

/*
 * move routines
 */
extern void	move(float x, float y, float z);
extern void	move2(float x, float y);
extern void	rmove(float dx, float dy, float dz);
extern void	rmove2(float dx, float dy);
extern void	smove2(float xs, float ys);
extern void	rsmove2(float dxs, float dys);

/*
 * object routines
 */
extern int	isobj(int n);
extern int	genobj(void);
extern void	delobj(int n);
extern void	makeobj(int n);
extern void	loadobj(int n, char *file);
extern void	saveobj(int n, char *file);
extern void	callobj(int n);
extern void	closeobj(void);
extern int	getopenobj(void);
extern Token	*newtokens(int num);

/*
 * patch routines.
 */
extern void	patch(Matrix geomx, Matrix geomy, Matrix geomz);
extern void	rpatch(Matrix geomx, Matrix geomy, Matrix geomz, Matrix geomw);
extern void	drpatch(Tensor R, int ntcurves, int nucurves, int ntsegs, int nusegs, int ntiter, int nuiter);
extern void	patchbasis(Matrix tb, Matrix ub);
extern void	patchcurves(int nt, int nu);
extern void	patchprecision(int tseg, int useg);
extern void	transformtensor(Tensor S, Matrix m);

/*
 * point routines
 */
extern void	point(float x, float y, float z);
extern void	point2(float x, float y);
extern void	spoint2(float xs, float ys);

/*
 * polygon routines.
 */
extern void	poly(int n, float dp[][3]);
extern void	poly2(int n, float dp[][2]);
extern void     hatchang(float a);
extern void	makepoly(void);
extern void	polyfill(int onoff);
extern void	closepoly(void);
extern void	polyhatch(int onoff);
extern void     hatchpitch(float a);
extern void	backface(int onoff);
extern void	backfacedir(int cdir);

extern void	polyobj(int n, Token dp[]);
extern void	pmove(float x, float y, float z);
extern void	pdraw(float x, float y, float z);

/*
 * rectangle routine
 */
extern void	rect(float x1, float y1, float x2, float y2);
extern void	srect(float x1, float y1, float x2, float y2);

/*
 * tensor routines
 */
extern void multtensor(Tensor c, Matrix a, Tensor b);
extern void copytensor(Tensor b, Tensor a);
extern void premulttensor(Tensor c, Matrix a, Tensor b);
extern void copytensortrans(Tensor b, Tensor a);

/*
 * text routines
 */
extern int	hershfont(char *fontname);
extern void	font(char *name);
extern void	boxfit(float l, float h, int nchars);
extern void	boxtext(float x, float y, float l, float h, char *s);
extern void	drawstr(char *string);
extern int	getstring(int bcol, char *s);
extern void	textang(float ang);
extern int	numchars(void);
extern void	drawchar(int c);
extern void	textsize(float width, float height);
extern float	strlength(char *s);
extern float	sstrlength();
extern void	centertext(int onoff);
extern void	xcentertext(void);
extern void	ycentertext(void);
extern void	fixedwidth(int onoff);
extern void	topjustify(void);
extern void	bottomjustify(void);
extern void	leftjustify(void);
extern void	rightjustify(void);
extern void	textjustify(unsigned val);
extern void	textslant(float val);
extern void	textweight(int val);
extern void	getcharsize(char c, float *width, float *height);
extern void	getfontsize(float *cw, float *ch);
extern float	getfontwidth(void);
extern float	getfontheight(void);

/*
 * transformation routines
 */
extern void	scale(float x, float y, float z);
extern void	translate(float x, float y, float z);
extern void	rotate(float r, char axis);

/*
 * window definition routines
 */
extern void	ortho(float left, float right, float bottom, float top,                               float hither, float yon);
extern void	ortho2(float left, float right, float bottom, float top);
extern void	lookat(float vx, float vy, float vz, float px, float py,                               float pz, float twist);
extern void	window(float left, float right, float bottom, float top,                               float hither, float yon);
extern void	polarview(float dist, float azim, float inc, float twist);
extern void	perspective(float fov, float aspect, float hither, float yon);
extern void	up(float x, float y, float z);

/*
 * routines for manipulating the viewport
 */
extern void	viewport(float xlow, float xhigh, float ylow, float yhigh);
extern void	getviewport(float *left, float *right,float *bottom,float *top);
extern void	popviewport(void);
extern void	pushviewport(void);

/*
 * routines for retrieving the graphics position
 */
extern void	getgp(float *x, float *y, float *z);
extern void	getgpt(float *x, float *y, float *z, float *w);
extern void	getgp2(float *x, float *y);
extern void	sgetgp2(float *x, float *y);

/*
 * routines for retrieving the aspect details of the device
 */
extern float	getaspect(void);
extern void	getfactors(float *x, float *y);
extern void	getdisplaysize(float *x, float *y);
extern void	expandviewport(void);
extern void	unexpandviewport(void);

/*
 * routines for handling the buffering
 */
extern int	backbuffer(void);
extern void	frontbuffer(void);
extern int	swapbuffers(void);

/*
 * routines for window sizing and positioning
 */
extern void	prefsize(int x, int y);
extern void	prefposition(int x, int y);
extern void	getprefposandsize(int *x, int *y, int * xs, int *ys);

/* 
 * Misc control routines
 */
extern void	clip(Vector p0, Vector p1);
extern void	quickclip(Vector p0, Vector p1);
extern void	clipping(int onoff);
extern void	vsetflush(int yn);
extern void	vflush(void);
extern void	yobbarays(int onoff);
extern FILE	*_voutfile(void);

/*
 * Error handling routines
 */
#endif
