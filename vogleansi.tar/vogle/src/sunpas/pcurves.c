#include "vogle.h"

/*
 * CurveBasis
 */
void
CurveBasis(float basis[4][4])
{
	curvebasis(basis);
}

/*
 * CurvePrecision
 */
void
CurvePrecision(int nsegments)
{
	curveprecision(nsegments);
}

/*
 * Rcurve
 */
void
Rcurve(float geom[4][4])
{
	rcurve(geom);
}

/*
 * curve
 */
void
Curve(float geom[4][3])
{
	curve(geom);
}

/*
 * Curven
 */
void
Curven(int n, float geom[][3])
{
	curven(n, geom);
}
