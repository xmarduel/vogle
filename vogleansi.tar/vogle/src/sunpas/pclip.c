#include "vogle.h"

/*
 * Clipping
 *
 *	turn clipping on/off
 */
void
Clipping(int onoff)
{
	vdevice.clipoff = !onoff;
}
