#include <stdio.h>
#include "vogle.h"

static int	(*verrorhandlerfunc)(int errno, char *msg) = NULL;
/*
 * verror
 *
 *	print an error on the graphics device, and then exit. Only called
 * for fatal errors. We assume that stderr is always there.
 *
 */
void
verror(char *str)
{

	printf("verrorhandlerfunc = 0x%x\n", verrorhandlerfunc);
	if (verrorhandlerfunc != NULL)
		if (verrorhandlerfunc(1, str) == 0)
			return;
#ifdef MSWIN
	mswin_verror(str);
	if (vdevice.initialised)
		vexit();
#else
#ifdef OS2
    PM_verror(str);
    if (vdevice.initialised)
        vexit();
#else
	if (vdevice.initialised)
		vexit();

	fprintf(stderr, "%s\n", str);
#endif
#endif
	exit(1);
}

void
verrorhandler(int (*f)(int en, char *m))
{
	verrorhandlerfunc = f;
}
