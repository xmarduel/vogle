#define IDM_ABOUT 100

#ifndef TC
int PASCAL WinMain(HANDLE, HANDLE, LPSTR, int);
#endif
BOOL InitApplication(HANDLE);
BOOL InitInstance(HANDLE, int);
long FAR PASCAL MainWndProc(HWND, unsigned, WORD, LONG);
#ifndef TC
BOOL FAR PASCAL About(HWND, unsigned, WORD, LONG);
#endif
