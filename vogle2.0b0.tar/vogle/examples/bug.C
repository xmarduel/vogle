#include <iostream.h>
#include "vogle.h"

void make_display(int OBJ)
{
  float  XMax, YMax, wfac, hfac;
  float eps=20;
  makeobj(OBJ);
  calcviewport();
  color(7); clear(); color(BLACK);
  ortho2(0.0,XMax,0.0,YMax);
  move2(eps,eps);
  color(RED);
  setdash(0.01);
  linestyle("10");
  draw2(XMax-eps,eps); 
  linestyle("110");
  color(MAGENTA);
  draw2(XMax-eps,YMax-eps); 
  color(BLUE);
  setdash(0.02);
  draw2(eps,YMax-eps); 
//  linestyle(" ");
  linestyle(0);
//  color(BLACK);
  color(GREEN);
  draw2(eps,eps);
  linestyle("110");
	printf("circle(%f, %f, %f)\n", XMax/2,YMax/2,YMax*0.45);
  circle(XMax/2,YMax/2,YMax*0.45);
  closeobj();
}

// #define PS

int main(int , char **argv)
{ int MaxX=1000,MaxY=250, PosX=0, PosY=0;
  char device[]="X11";
//  char device[]="ppostscript";
  char Ans;
  float wfac, hfac;
  prefsize(MaxX,MaxY);
  prefposition(PosX, PosY);

//  cout << "XMax= " << XMax << "    YMax= " << YMax 
//       << "   Aspect: " << getaspect() << endl;

  int   win;
  const int Obj = 1;

  win= winopen("","Title");
  expandviewport();
  getfactors(&wfac,&hfac);
// viewport width is 2.0 (-1.0...1.0), so the correction for non-square is:
  if ( hfac < wfac ) wfac = 2.0*wfac -hfac;
  else               hfac = 2.0*hfac-wfac;
// set 'distortion',use 1/1 screen
  viewport(-1.0,wfac,-1.0,hfac);

  voutput("VTest.ps");
  prefsize(-1,-1);
  prefposition(-1,-1);
  cerr << "doing the cps thing\n";
  win = winopen("cps", "");
  make_display(Obj);
  color(RED);
  clear();
  callobj(Obj);
  
  Vevent	vev;
  int	skip = 0;
  
  do {
	  int	w;
	  w = vgetevent(&vev);
	  if (w != -1) {
		  winset(w);
		  cerr << "Window = " << w << endl;
		  switch (vev.type) {
		  case VRESIZE:
			  cerr << "VRESIZE\n";
			  calcviewport();
		  case VREDRAW:
			  cerr << "VREDRAW\n";
			  callobj(Obj);

			  break;
		  case VKEYPRESS:
		  	cerr << "Key pressed\n";
			  skip = 1;
			  break;
		  default:
			  ;
		  }
	  }
  } while(vev.type != -1 && !skip);

/**/
  windel(win);
  prefsize(-1,-1);
  prefposition(-1,-1);
  voutput("VTest.ps");
  cerr << "cps output now\n";
  win = winopen("cps", "");
  color(RED);
  clear();
  callobj(Obj);
  winclose(win);
/**/
  vexit();
  return 0;
}





