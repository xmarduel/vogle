#include "vogle.h"

/*
 * PushAttributes
 */
void
PushAttributes(void)
{
	pushattributes();
}

/*
 * PopAttributes
 */
void
PopAttributes(void)
{
	popattributes();
}

