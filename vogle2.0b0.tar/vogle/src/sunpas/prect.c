#include "vogle.h"
/*
 * Rect
 */
void
Rect(double x1, double y1, double x2, double y2)
{
	rect(x1, y1, x2, y2);
}
