#include "vogle.h"

/*
 * Yobbarays
 *
 */
void
Yobbarays(int onoff)
{
	yobbarays(onoff);
}
