#include "vogle.h"

/*
 * Point
 */
void
Point(double x, double y, double z)
{
	point(x, y, z);
}

/*
 * Point2
 */
void
Point2(double x, double y)
{
	point(x, y, 0.0);
}

