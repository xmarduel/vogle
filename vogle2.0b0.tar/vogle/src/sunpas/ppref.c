#include "vogle.h"

/*
 * PrefPosition
 */
void
PrefPosition(int x, int y)
{
	prefposition(x, y);
}

/*
 * PrefSize
 */
void
PrefSize(int x, int y)
{
	prefsize(x, y);
}
