#include "vogle.h"

/*
 * getgp_
 */
void
getgp_(float *x, float *y, float *z)
{
	getgp(x, y, z);
}

/*
 * getgpt_
 */
void
getgpt_(float *x, float *y, float *z, float *w)
{
	getgpt(x, y, z, w);
}

/*
 * getgp2_
 */
void
getgp2_(float *x, float *y)
{
	getgp2(x, y);
}

/*
 * sgetgp2_
 */
void
sgetgp2_(float *x, float *y)
{
	sgetgp2(x, y);
}

/*
 * pushpos_
 */
void
pushpos_(void)
{
	pushpos();
}

/*
 * poppos_
 */
void
poppos_(void)
{
	poppos();
}

