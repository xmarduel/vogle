#include "vogle.h"

/*
 * point_
 */
void
point_(float *x, float *y, float *z)
{
	point(*x, *y, *z);
}

/*
 * point2_
 */
void
point2_(float *x, float *y)
{
	point(*x, *y, 0.0);
}

