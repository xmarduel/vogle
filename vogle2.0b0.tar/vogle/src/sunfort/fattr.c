#include "vogle.h"

/*
 * pushattributes_
 */
void
pushattributes_(void)
{
	pushattributes();
}

/*
 * popattributes_
 */
void
popattributes_(void)
{
	popattributes();
}

