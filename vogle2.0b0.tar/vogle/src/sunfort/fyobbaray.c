#include "vogle.h"

/*
 * yobbarays_
 *
 */
void
yobbarays_(int *onoff)
{
	yobbarays(*onoff);
}
